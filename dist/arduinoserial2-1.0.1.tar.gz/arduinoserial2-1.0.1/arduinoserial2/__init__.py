from arduinoserial2.arduinoserial2 import checks,read,read_start,send_data,connect,detect
